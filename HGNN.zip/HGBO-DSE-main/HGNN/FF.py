from torch_geometric.loader import DataLoader
from dataset_utils import *
import torch
import torch.nn.functional as F
from torch import nn
from torch_geometric.nn.conv import SAGEConv, GCNConv, GATConv, GATConv
from torch_geometric.nn.dense import Linear
# from torch_geometric.nn.models import JumpingKnowledge
from torch_geometric.nn.pool import global_add_pool, global_max_pool, SAGPooling


target = ['lut', 'ff', 'dsp', 'bram', 'uram', 'srl', 'cp', 'power']
tar_idx = 1
jknFlag = 0


class CAGNN(torch.nn.Module):
    def __init__(self, in_channels, hidden_channels, hls_dim , num_layers=3, dropout=0.0,
                 norm_type='None', conv_type='sage', gate_type='convex', pool_ratio=0.5):
        super().__init__()

        self.drop_out = dropout
        self.num_layers = num_layers
        self.norm_type = norm_type
        self.conv_type = conv_type
        self.dropout = nn.Dropout(dropout)
        self.gate_type = gate_type
        self.pool_ratio = pool_ratio

        # encoder, message passing, decoder
        self.encoder = nn.Linear(in_channels, hidden_channels)
        self.build_message_passing_layers(num_layers, hidden_channels)
        self.channels = [hidden_channels * 2 + hls_dim, 64, 64, 1]
        self.mlps = torch.nn.ModuleList()

        for i in range(len(self.channels) - 1):
            fc = Linear(self.channels[i], self.channels[i + 1])
            self.mlps.append(fc)


        if gate_type == 'convex':
            self.gate = nn.Linear(hidden_channels * 2, 1)
        elif gate_type == 'convex_MLP_2':
            self.gate = nn.Sequential(
                nn.Linear(hidden_channels * 2, hidden_channels),
                nn.ReLU(),
                nn.Linear(hidden_channels, 1)
            )
        elif gate_type == 'convex_MLP_3':
            self.gate = nn.Sequential(
                nn.Linear(hidden_channels * 2, hidden_channels * 2),
                nn.ReLU(),
                nn.Linear(hidden_channels * 2, hidden_channels),
                nn.ReLU(),
                nn.Linear(hidden_channels, 1)
            )
        elif gate_type == 'concat':
            self.decoder = nn.Linear(hidden_channels*(num_layers+1), out_channels)
        elif gate_type == 'global':
            self.alpha_scalar = nn.Parameter(torch.randn(num_layers+1))
        # self.g = self.set_g(g)

    # def set_g(self, adj):
    #     if self.conv_type == 'gat':
    #         if isinstance(adj, SparseTensor):
    #             row, col, _ = adj.coo()
    #             adj = torch.cat([row.unsqueeze(0), col.unsqueeze(0)], dim=0)
    #         elif isinstance(adj, torch.Tensor):
    #             if adj.shape[0] == adj.shape[1]:
    #                 adj = adj.nonzero().t()
    #     return adj

    def build_message_passing_layers(self, num_layers, hid_channesl):
        self.conv_layers = nn.ModuleList()
        self.pools = torch.nn.ModuleList()
        self.learnable_norm_self = nn.ModuleList()
        self.learnable_norm_neighb = nn.ModuleList()
        self.transforms = nn.ModuleList()

        if self.norm_type == 'bn':
            self.learnable_norm_self.append(nn.BatchNorm1d(hid_channesl))
            self.learnable_norm_neighb.append(nn.BatchNorm1d(hid_channesl))
        elif self.norm_type == 'ln':
            self.learnable_norm_self.append(nn.LayerNorm(hid_channesl))
            self.learnable_norm_neighb.append(nn.LayerNorm(hid_channesl))

        for i in range(num_layers):
            if self.conv_type == 'gcn':
                layer = GCNConv(hid_channesl, hid_channesl)
            elif self.conv_type == 'gin':
                layer = GINConv(hid_channesl, hid_channesl)
            elif self.conv_type == 'gat':
                layer = GATConv(hid_channesl, hid_channesl, dropout=0, drop_edge=0, alpha=0.2, nheads=1)
            elif self.conv_type == 'sage':
                layer = SAGEConv(hid_channesl, hid_channesl)
            else:
                raise 'not implement'

            self.conv_layers.append(layer)
            self.pools.append(SAGPooling( hid_channesl, self.pool_ratio))

            if self.gate_type == 'convex_multi_map':
                self.transforms.append(nn.Linear(hid_channesl, hid_channesl))
            if self.norm_type == 'bn':
                self.learnable_norm_self.append(nn.BatchNorm1d(hid_channesl))
                self.learnable_norm_neighb.append(nn.BatchNorm1d(hid_channesl))
            elif self.norm_type == 'ln':
                self.learnable_norm_self.append(nn.LayerNorm(hid_channesl))
                self.learnable_norm_neighb.append(nn.LayerNorm(hid_channesl))

    def propagate(self, adj, x, layer_index):
        x = self.conv_layers[layer_index](adj, x)
        return x

    def update(self, self_x, conv_x, layer_index=0):
        if self.gate_type in ['convex', 'convex_MLP_2', 'convex_MLP_3']:
            a = self.gate(torch.cat([self_x, conv_x], dim=1)).sigmoid()
            self_x = a * self_x + (1 - a) * conv_x
        elif self.gate_type == 'vector':
            a = self.gate_vector(torch.cat([self_x, conv_x], dim=1)).sigmoid()
            self_x = a * self_x + (1 - a) * conv_x
        elif self.gate_type == 'global':
            a = self.alpha_scalar[layer_index].sigmoid()
            self_x = a * self_x + (1 - a) * conv_x
        elif self.gate_type == 'add':
            self_x = self_x + conv_x
        elif self.gate_type == 'concat':
            self_x = torch.cat([self_x, conv_x], dim=1)
        else:
            self_x = conv_x
        return self_x, conv_x

    def norm(self, x, layer_index=0, is_self=False):
        if is_self and self.gate_type == 'concat':
            return x
        if self.norm_type == 'l2':
            x = F.normalize(x, p=2, dim=1)
        elif self.norm_type in ['bn', 'ln']:
            if is_self:
                x = self.learnable_norm_self[layer_index](x)
            else:
                x = self.learnable_norm_neighb[layer_index](x)
        return x

    def forward(self, x, edge_index, batch, hls_attr):

        x = x.to(torch.float32)
        h_list = []

        adj = edge_index
        x = self.dropout(x)
        init_x = self.encoder(x).relu()
        init_x = self.norm(init_x, 0, is_self=True)
        self_x, conv_x = init_x, init_x
        for i in range(self.num_layers):
            conv_x = self.dropout(conv_x)
            conv_x = self.conv_layers[i](conv_x, adj)
            self_x, conv_x = self.update(self_x, conv_x, i)
            self_x = self.norm(self_x, i, is_self=True)
            conv_x = self.norm(conv_x, i)
            h = torch.cat([global_max_pool(self_x, batch), global_add_pool(self_x, batch)], dim=1)
            h_list.append(h)
        h = 3 * h_list[2] - h_list[0] - h_list[1]
        h = self.dropout(h)
        # print("Shape of h:", h.shape)
        # print("Shape of hls_attr:", hls_attr.shape)
        h = torch.cat([h, hls_attr], dim=-1)

        for f in range(len(self.mlps)):
            if f < len(self.mlps) - 1:
                h = F.relu(self.mlps[f](h))
                h = F.dropout(h, p=self.drop_out, training=self.training)
            else:
                h = self.mlps[f](h)

        return h

def train(model, train_loader):
    model.train()
    total_mse = 0
    total_mape = 0
    for _, data in enumerate(train_loader):
        data = data.to(device)
        optimizer.zero_grad()
        hls_attr = data['hls_attr']
        out = model(data.x, data.edge_index, data.batch, hls_attr)
        out = out.view(-1)
        true_y = data['y'].t()
        mse = F.huber_loss(out, true_y[tar_idx]).float()
        mape = mape_loss(out, true_y[tar_idx]).float()
        loss = mse
        loss.backward()
        optimizer.step()
        total_mse += mse.item() * data.num_graphs
        total_mape += mape.item() * data.num_graphs
    ds = train_loader.dataset
    total_mse = total_mse / len(ds)
    total_mape = total_mape / len(ds)

    return total_mse, total_mape


def test(model, loader, epoch):
    model.eval()
    with torch.no_grad():
        mse = 0
        mape = 0
        y = []
        y_hat = []
        residual = []
        for _, data in enumerate(loader):
            data = data.to(device)
            hls_attr = data['hls_attr']
            out = model(data.x, data.edge_index, data.batch, hls_attr)
            out = out.view(-1)
            true_y = data['y'].t()
            mse += F.huber_loss(out, true_y[tar_idx]).float().item() * data.num_graphs  # MSE
            mape += mape_loss(out, true_y[tar_idx]).float().item() * data.num_graphs  # MAE
            y.extend(true_y[tar_idx].cpu().numpy().tolist())
            y_hat.extend(out.cpu().detach().numpy().tolist())
            residual.extend((true_y[tar_idx] - out).cpu().detach().numpy().tolist())
        if epoch % 10 == 0:
            print('pred.y:', out)
            print('data.y:', true_y[tar_idx])
        ds = loader.dataset
        mse = mse / len(ds)
        mape = mape / len(ds)
    return mse, mape


if __name__ == "__main__":
    batch_size = 32
    dataset_dir = os.path.abspath('../dataset/std')
    model_dir = os.path.abspath('./model')
    dataset = os.listdir(dataset_dir)
    dataset_list = generate_dataset(dataset_dir, dataset, print_info=False)
    train_ds, test_ds = split_dataset(dataset_list, shuffle=True, seed=128)
    print('train_ds size = {}, test_ds size = {}'.format(len(train_ds), len(test_ds)))

    train_loader = DataLoader(train_ds, batch_size=batch_size, shuffle=True, drop_last=True)
    test_loader = DataLoader(test_ds, batch_size=batch_size, shuffle=True, drop_last=True)

    data_ini = None
    for step, data in enumerate(train_loader):
        if step == 0:
            data_ini = data
            break

    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    model = CAGNN( in_channels=data_ini.num_features, hidden_channels=64, hls_dim=6,num_layers=3,
                  dropout=0.0,
                  norm_type='ln', conv_type='sage', gate_type='global')
    model = model.to(device)
    print(model)

    LR = 0.005
    optimizer = torch.optim.Adam(model.parameters(), lr=LR, weight_decay=0.001)
    # scheduler = torch.optim.lr_scheduler.ExponentialLR(optimizer, gamma=0.9, last_epoch=-1)

    min_train_mape = 1
    min_test_mape = 1
    for epoch in range(500):
        train_loss, train_mape = train(model, train_loader)
        test_loss, test_mape = test(model, test_loader, epoch)
        print(f'Epoch: {epoch:03d}, Train Loss: {train_loss:.4f}, Test Loss: {test_loss:.4f}')
        print(f'Epoch: {epoch:03d}, Train MAPE: {train_mape:.4f}, Test MAPE: {test_mape:.4f}')

        if epoch % 10 == 0:
            # scheduler.step()
            for p in optimizer.param_groups:
                p['lr'] *= 0.9

        save_train = False
        if train_mape < min_train_mape:
            min_train_mape = train_mape
            save_train = True

        save_test = False
        if test_mape < min_test_mape:
            min_test_mape = test_mape
            save_test = True

        checkpoint_1 = {
            'model': model.state_dict(),
            'optimizer': optimizer.state_dict(),
            'epoch': epoch,
            'min_train_mape': min_train_mape
        }

        checkpoint_2 = {
            'model': model.state_dict(),
            'optimizer': optimizer.state_dict(),
            'epoch': epoch,
            'min_test_mape': min_test_mape
        }

        if save_train:
            torch.save(checkpoint_1, os.path.join(model_dir, target[tar_idx] + '_mae_h64_d0_checkpoint_train.pt'))

        if save_test:
            torch.save(checkpoint_2, os.path.join(model_dir, target[tar_idx] + '_mae_h64_d0_checkpoint_test.pt'))

    print('Min Train MAPE: ' + str(min_train_mape))
    print('Min Test MAPE: ' + str(min_test_mape))

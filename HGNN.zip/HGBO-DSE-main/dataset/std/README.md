Standard dataset is available at https://pan.baidu.com/s/1vuNft44EYGcK7SKpoXHm6w. 
(Extraction code: cewy)

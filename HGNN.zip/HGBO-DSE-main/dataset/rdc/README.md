Simplified dataset is available at https://pan.baidu.com/s/1TI38LOMo5PcZPOgKQZjxEQ.
(Extraction code: g6xn)

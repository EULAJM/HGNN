## How to run PowerGear
1. Run generate_test.py
2. Run feature_extract.py
3. Run get_pow.py to get power_measurement.csv
4. Run sample_generation.py to get pt files
5. Run main.py to train model